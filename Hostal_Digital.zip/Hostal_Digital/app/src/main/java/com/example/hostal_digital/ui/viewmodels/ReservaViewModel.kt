package com.example.hostal_digital.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.hostal_digital.domain.entities.Reserva
import com.example.hostal_digital.domain.entities.Habitacion
import com.example.hostal_digital.domain.entities.Usuario
import com.example.hostal_digital.domain.usecases.ListarHabitacionesUseCase
import com.example.hostal_digital.domain.usecases.CancelarReservaUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ReservaViewModel(
    private val listarUseCase: ListarHabitacionesUseCase,
    private val cancelarUseCase: CancelarReservaUseCase
) : ViewModel() {

    // Para usuario normal: lista de reservas
    private val _reservasUsuario = MutableStateFlow<List<Reserva>>(emptyList())
    val reservasUsuario: StateFlow<List<Reserva>> get() = _reservasUsuario

    // Para admin: lista de habitaciones con usuario (Pair<Habitacion, Usuario>)
    private val _reservasAdmin = MutableStateFlow<List<Pair<Habitacion, Usuario>>>(emptyList())
    val reservasAdmin: StateFlow<List<Pair<Habitacion, Usuario>>> get() = _reservasAdmin

    private val _actionSuccess = MutableStateFlow<Boolean?>(null)
    val actionSuccess: StateFlow<Boolean?> get() = _actionSuccess

    /** Listar reservas de un usuario logueado */
    fun listarReservas(usuarioId: Int) {
        viewModelScope.launch {
            _reservasUsuario.value = listarUseCase.getAll(usuarioId)
        }
    }

    /** Listar todas las reservas para admin */
    fun listarTodasReservas() {
        viewModelScope.launch {
            _reservasAdmin.value = listarUseCase.getAllReservadasParaAdmin()
        }
    }

    /** Cancelar reserva */
    fun cancelarReserva(idReserva: Int) {
        viewModelScope.launch {
            val success = cancelarUseCase.cancelarReserva(idReserva)
            _actionSuccess.value = success
            if (success) {
                // Actualizar listado del usuario
                _reservasUsuario.value = _reservasUsuario.value.filter { it.id != idReserva }
                // Actualizar listado admin
                _reservasAdmin.value = _reservasAdmin.value.filter { it.first.id != idReserva }
            }
        }
    }

    companion object {
        fun provideFactory(
            listarUseCase: ListarHabitacionesUseCase,
            cancelarUseCase: CancelarReservaUseCase
        ) = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return ReservaViewModel(listarUseCase, cancelarUseCase) as T
            }
        }
    }
}
