package com.example.hostal_digital.data.dao

import androidx.room.*
import com.example.hostal_digital.data.entities.ReservaEntity
import java.util.Date

@Dao
interface ReservaDAO {

    @Query("SELECT * FROM ReservaEntity")
    fun getAll(): List<ReservaEntity>

    @Query("SELECT * FROM ReservaEntity WHERE id = :id")
    fun getById(id: Int): ReservaEntity?

    @Insert
    fun insert(reserva: ReservaEntity): Long

    @Update
    fun update(reserva: ReservaEntity): Int

    @Delete
    fun delete(reserva: ReservaEntity): Int
}
