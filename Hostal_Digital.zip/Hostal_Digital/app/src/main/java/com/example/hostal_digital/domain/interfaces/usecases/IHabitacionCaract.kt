package com.example.hostal_digital.domain.interfaces.usecases

import com.example.hostal_digital.domain.entities.Habitacion

interface IHabitacionCaract {

    fun caracteristicas(idHabitacion: Int): Habitacion?
}
