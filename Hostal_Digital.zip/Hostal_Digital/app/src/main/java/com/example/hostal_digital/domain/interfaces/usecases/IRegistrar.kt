package com.example.hostal_digital.domain.interfaces.usecases

interface IRegistrar {

    fun registrar(
        nombre: String,
        contrasena: String
    ): Boolean
}
