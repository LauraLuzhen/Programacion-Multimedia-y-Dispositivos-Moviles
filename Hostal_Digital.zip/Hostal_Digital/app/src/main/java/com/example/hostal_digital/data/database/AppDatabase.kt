package com.example.hostal_digital.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.hostal_digital.data.converters.DateConverter
import com.example.hostal_digital.data.dao.HabitacionDAO
import com.example.hostal_digital.data.dao.UsuarioDAO
import com.example.hostal_digital.data.dao.ReservaDAO
import com.example.hostal_digital.data.entities.HabitacionEntity
import com.example.hostal_digital.data.entities.UsuarioEntity
import com.example.hostal_digital.data.entities.ReservaEntity

@Database(
    entities = [HabitacionEntity::class, UsuarioEntity::class, ReservaEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(DateConverter::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun habitacionDao(): HabitacionDAO
    abstract fun usuarioDao(): UsuarioDAO
    abstract fun reservaDao(): ReservaDAO

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "hostal_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
