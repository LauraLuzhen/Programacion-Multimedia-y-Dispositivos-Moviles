package com.example.hostal_digital.domain.usecases

import com.example.hostal_digital.domain.interfaces.repositories.IHabitacionesRepository
import com.example.hostal_digital.domain.interfaces.repositories.IReservasRepository

class CancelarReservaUseCase(
    private val reservasRepository: IReservasRepository,
    private val habitacionesRepository: IHabitacionesRepository
) {

    /**
     * Cancela una reserva
     * @param idReserva Id de la reserva a cancelar
     * @return true si se canceló correctamente, false si no
     */
    fun cancelarReserva(idReserva: Int): Boolean {
        val reserva = reservasRepository.getById(idReserva)
            ?: return false // No existe la reserva


        val habitacion = habitacionesRepository.getById(reserva.idHabitacion)
            ?: return false // Si falla encontrar habitación, aborta

        // Borramos la reserva
        val eliminado = reservasRepository.delete(idReserva)
        if (!eliminado) return false

        // Liberamos la habitación
        val actualizacion = habitacionesRepository.update(
            id = habitacion.id,
            numCamas = habitacion.numCamas,
            numAseos = habitacion.numAseos,
            reservada = false
        )

        return actualizacion
    }
}
