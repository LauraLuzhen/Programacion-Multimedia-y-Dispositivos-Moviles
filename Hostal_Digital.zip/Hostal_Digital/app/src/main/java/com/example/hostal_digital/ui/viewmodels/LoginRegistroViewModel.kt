package com.example.hostal_digital.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.hostal_digital.domain.usecases.LoginRegistroUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class LoginRegistroViewModel(
    private val useCase: LoginRegistroUseCase
) : ViewModel() {

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> get() = _loginError

    fun login(nombre: String, contrasena: String, onSuccess: (Int) -> Unit) {
        viewModelScope.launch {
            val userId = useCase.verificar(nombre, contrasena)
            if (userId != -1) {
                _loginError.value = null
                onSuccess(userId)
            } else {
                _loginError.value = "Usuario o contraseña incorrectos"
            }
        }
    }

    fun registrar(nombre: String, contrasena: String, onSuccess: (Boolean) -> Unit) {
        viewModelScope.launch {
            val created = useCase.registrar(nombre, contrasena)
            if (created) _loginError.value = null
            onSuccess(created)
        }
    }

    companion object {
        fun provideFactory(useCase: LoginRegistroUseCase) = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return LoginRegistroViewModel(useCase) as T
            }
        }
    }
}
