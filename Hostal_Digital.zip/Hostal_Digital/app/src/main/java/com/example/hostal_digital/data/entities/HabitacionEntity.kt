package com.example.hostal_digital.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class HabitacionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val numero: Int,
    val reservada: Boolean,
    val numCamas: Int,
    val numAseos: Int
)
