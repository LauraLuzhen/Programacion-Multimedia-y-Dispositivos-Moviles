package com.example.hostal_digital.domain.interfaces.usecases

import java.util.Date

interface IReservarHabitacion {

    fun reservar(
        idHabitacion: Int,
        idUsuario: Int,
        fechaEntrada: Date,
        fechaSalida: Date
    ): Boolean
}
