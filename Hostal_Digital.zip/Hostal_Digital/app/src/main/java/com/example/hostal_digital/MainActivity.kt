package com.example.hostal_digital

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.hostal_digital.data.database.AppDatabase
import com.example.hostal_digital.data.repositories.HabitacionesRepository
import com.example.hostal_digital.data.repositories.ReservasRepository
import com.example.hostal_digital.data.repositories.UsuariosRepository
import com.example.hostal_digital.domain.usecases.*
import com.example.hostal_digital.ui.viewmodels.*
import com.example.hostal_digital.ui.views.*

enum class Screen {
    LOGIN_REGISTRO,
    LISTADO_HABITACIONES,
    HABITACION_CARACT,
    HABITACION_RESERVA,
    RESERVAS
}

class MainActivity : ComponentActivity() {

    // Repositorios
    private val habitacionesRepo by lazy {
        HabitacionesRepository(AppDatabase.getDatabase(applicationContext).habitacionDao())
    }
    private val usuariosRepo by lazy {
        UsuariosRepository(AppDatabase.getDatabase(applicationContext).usuarioDao())
    }
    private val reservasRepo by lazy {
        ReservasRepository(AppDatabase.getDatabase(applicationContext).reservaDao())
    }

    // UseCases
    private val habitacionUseCase by lazy { HabitacionUseCase(habitacionesRepo, reservasRepo) }
    private val listarUseCase by lazy { ListarHabitacionesUseCase(habitacionesRepo, usuariosRepo, reservasRepo) }
    private val loginUseCase by lazy { LoginRegistroUseCase(usuariosRepo) }
    private val cancelarUseCase by lazy { CancelarReservaUseCase(reservasRepo, habitacionesRepo) }

    // ViewModels
    private val habitacionVM: HabitacionViewModel by viewModels { HabitacionViewModel.provideFactory(habitacionUseCase) }
    private val loginVM: LoginRegistroViewModel by viewModels { LoginRegistroViewModel.provideFactory(loginUseCase) }
    private val reservaVM: ReservaViewModel by viewModels { ReservaViewModel.provideFactory(listarUseCase, cancelarUseCase) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            var currentScreen by remember { mutableStateOf(Screen.LOGIN_REGISTRO) }
            var usuarioId by remember { mutableStateOf(-1) }
            var habitacionSeleccionadaId by remember { mutableStateOf(-1) }

            // Determinar si el usuario es admin
            val isAdmin = usuarioId == 0

            when (currentScreen) {
                Screen.LOGIN_REGISTRO -> {
                    LoginRegistro(viewModel = loginVM, onLoginSuccess = { id ->
                        if (id != -1) {
                            usuarioId = id
                            currentScreen = Screen.LISTADO_HABITACIONES
                        }
                    })
                }

                Screen.LISTADO_HABITACIONES -> {
                    val habitaciones = listarUseCase.getAll()
                    ListadoHabitaciones(
                        habitaciones = habitaciones,
                        usuarioId = usuarioId,
                        onHabitacionClick = { habit ->
                            habitacionSeleccionadaId = habit.id
                            currentScreen = Screen.HABITACION_CARACT
                        }
                    )
                }

                Screen.HABITACION_CARACT -> {
                    HabitacionCaract(
                        viewModel = habitacionVM,
                        idHabitacion = habitacionSeleccionadaId
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { currentScreen = Screen.HABITACION_RESERVA }) {
                        Text("Reservar")
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { currentScreen = Screen.LISTADO_HABITACIONES }) {
                        Text("Volver")
                    }
                }

                Screen.HABITACION_RESERVA -> {
                    HabitacionReserva(
                        viewModel = habitacionVM,
                        idHabitacion = habitacionSeleccionadaId,
                        usuarioId = usuarioId
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { currentScreen = Screen.LISTADO_HABITACIONES }) {
                        Text("Volver")
                    }
                }

                Screen.RESERVAS -> {
                    reservaVM.listarReservas(usuarioId)
                    reservaVM.listarTodasReservas()
                    ListadoHabitacionesReservadas(
                        reservasUsuario = reservaVM.reservasUsuario.collectAsStateWithLifecycle().value,
                        reservasAdmin = reservaVM.reservasAdmin.collectAsStateWithLifecycle().value,
                        isAdmin = isAdmin,
                        onCancelarReserva = { id -> reservaVM.cancelarReserva(id) }
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { currentScreen = Screen.LISTADO_HABITACIONES }) {
                        Text("Volver")
                    }
                }
            }
        }
    }
}
