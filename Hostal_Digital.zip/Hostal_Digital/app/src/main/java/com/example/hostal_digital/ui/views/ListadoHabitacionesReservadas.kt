package com.example.hostal_digital.ui.views

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.hostal_digital.domain.entities.Reserva
import com.example.hostal_digital.domain.entities.Habitacion
import com.example.hostal_digital.domain.entities.Usuario

@Composable
fun ListadoHabitacionesReservadas(
    reservasUsuario: List<Reserva>,
    reservasAdmin: List<Pair<Habitacion, Usuario>>,
    isAdmin: Boolean,
    onCancelarReserva: ((Int) -> Unit)? = null
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        if (isAdmin) {
            Text("Reservas totales (Admin)", style = MaterialTheme.typography.titleMedium)
            LazyColumn {
                items(reservasAdmin) { (habitacion, usuario) ->
                    Card(modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text("Habitación ${habitacion.numero}")
                            Text("Usuario: ${usuario.nombre}")
                        }
                    }
                }
            }
        } else {
            Text("Tus reservas", style = MaterialTheme.typography.titleMedium)
            LazyColumn {
                items(reservasUsuario) { reserva ->
                    Card(modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text("Habitación ID: ${reserva.idHabitacion}")
                            Text("Entrada: ${reserva.fechaEntrada}, Salida: ${reserva.fechaSalida}")
                            if (onCancelarReserva != null) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Button(onClick = { onCancelarReserva(reserva.id) }) {
                                    Text("Cancelar reserva")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
