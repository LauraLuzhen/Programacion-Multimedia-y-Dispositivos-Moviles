package com.example.hostal_digital.domain.usecases

import com.example.hostal_digital.domain.entities.Usuario
import com.example.hostal_digital.domain.interfaces.repositories.IUsuariosRepository
import com.example.hostal_digital.domain.interfaces.usecases.IVerificarLogin
import com.example.hostal_digital.domain.interfaces.usecases.IRegistrar

class LoginRegistroUseCase(
    private val usuariosRepository: IUsuariosRepository
) : IVerificarLogin, IRegistrar {

    /**
     * Verifica las credenciales de login
     * @return idUsuario si existe, -1 si no
     */
    override fun verificar(nombre: String, contrasena: String): Int {
        val usuarios = usuariosRepository.getAll()

        val usuario = usuarios.find { it.nombre == nombre && it.contrasena == contrasena }

        return usuario?.id ?: -1
    }

    /**
     * Registra un usuario nuevo con 0 reservas
     * @return true si se creó correctamente, false si el nombre ya existe
     */
    override fun registrar(nombre: String, contrasena: String): Boolean {
        // Comprobar que no exista ya un usuario con ese nombre
        val existe = usuariosRepository.getAll().any { it.nombre == nombre }
        if (existe) return false

        return usuariosRepository.create(nombre, contrasena)
    }
}
