package com.example.hostal_digital.domain.usecases

import com.example.hostal_digital.domain.entities.Habitacion
import com.example.hostal_digital.domain.entities.Reserva
import com.example.hostal_digital.domain.entities.Usuario
import com.example.hostal_digital.domain.interfaces.repositories.IHabitacionesRepository
import com.example.hostal_digital.domain.interfaces.repositories.IReservasRepository
import com.example.hostal_digital.domain.interfaces.repositories.IUsuariosRepository
import com.example.hostal_digital.domain.interfaces.usecases.IListarHabitaciones
import com.example.hostal_digital.domain.interfaces.usecases.IListarHabitacionesReservadas

class ListarHabitacionesUseCase(
    private val habitacionesRepository: IHabitacionesRepository,
    private val usuariosRepository: IUsuariosRepository,
    private val reservasRepository: IReservasRepository
) : IListarHabitaciones, IListarHabitacionesReservadas {

    /**
     * Listar todas las habitaciones
     */
    override fun getAll(): List<Habitacion> {
        return habitacionesRepository.getAll()
    }

    /**
     * Listar todas las reservas de un usuario específico
     */
    override fun getAll(idUsuario: Int): List<Reserva> {
        return reservasRepository.getAll().filter { it.idUsuario == idUsuario }
    }

    /**
     * Listar todas las habitaciones reservadas junto con el usuario al que pertenece la reserva
     * Solo para admin (id = 0)
     * @return lista de Pair<Habitacion, Usuario>
     */
    fun getAllReservadasParaAdmin(): List<Pair<Habitacion, Usuario>> {
        val reservas = reservasRepository.getAll().filter { reserva ->
            val habitacion = habitacionesRepository.getById(reserva.idHabitacion)
            habitacion?.reservada == true
        }

        val resultado = mutableListOf<Pair<Habitacion, Usuario>>()

        for (reserva in reservas) {
            val habitacion = habitacionesRepository.getById(reserva.idHabitacion)
            val usuario = usuariosRepository.getById(reserva.idUsuario)
            if (habitacion != null && usuario != null) {
                resultado.add(Pair(habitacion, usuario))
            }
        }

        return resultado
    }
}
