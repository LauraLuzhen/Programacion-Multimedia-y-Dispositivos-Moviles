package com.example.hostal_digital.data.repositories

import com.example.hostal_digital.data.dao.ReservaDAO
import com.example.hostal_digital.data.mappers.ReservaMapperDataDomain
import com.example.hostal_digital.domain.entities.Reserva
import com.example.hostal_digital.domain.interfaces.repositories.IReservasRepository
import java.util.Date

class ReservasRepository(
    private val reservaDao: ReservaDAO
) : IReservasRepository {

    override fun getAll(): List<Reserva> {
        return reservaDao.getAll().map { ReservaMapperDataDomain.toDomain(it) }
    }

    override fun getById(id: Int): Reserva? {
        return reservaDao.getById(id)?.let { ReservaMapperDataDomain.toDomain(it) }
    }

    override fun create(idHabitacion: Int, idUsuario: Int, fechaEntrada: Date, fechaSalida: Date): Boolean {
        val reserva = ReservaMapperDataDomain.toEntity(
            Reserva(
                id = 0,
                idHabitacion = idHabitacion,
                idUsuario = idUsuario,
                fechaEntrada = fechaEntrada,
                fechaSalida = fechaSalida
            )
        )
        return reservaDao.insert(reserva) > 0
    }

    override fun update(id: Int, idHabitacion: Int, idUsuario: Int, fechaEntrada: Date, fechaSalida: Date): Boolean {
        val reservaEntity = reservaDao.getById(id) ?: return false
        val updated = reservaEntity.copy(
            idHabitacion = idHabitacion,
            idUsuario = idUsuario,
            fechaEntrada = fechaEntrada,
            fechaSalida = fechaSalida
        )
        return reservaDao.update(updated) > 0
    }

    override fun delete(id: Int): Boolean {
        val reserva = reservaDao.getById(id) ?: return false
        return reservaDao.delete(reserva) > 0
    }
}
