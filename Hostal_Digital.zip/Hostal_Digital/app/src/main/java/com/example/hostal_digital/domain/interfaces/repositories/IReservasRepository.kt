package com.example.hostal_digital.domain.interfaces.repositories

import com.example.hostal_digital.domain.entities.Reserva
import java.util.Date

interface IReservasRepository {

    fun getAll(): List<Reserva>

    fun getById(id: Int): Reserva?

    fun create(
        idHabitacion: Int,
        idUsuario: Int,
        fechaEntrada: Date,
        fechaSalida: Date
    ): Boolean

    fun update(
        id: Int,
        idHabitacion: Int,
        idUsuario: Int,
        fechaEntrada: Date,
        fechaSalida: Date
    ): Boolean

    fun delete(id: Int): Boolean
}