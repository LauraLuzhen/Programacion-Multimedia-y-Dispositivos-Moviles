package com.example.hostal_digital.domain.interfaces.repositories

import com.example.hostal_digital.domain.entities.Habitacion

interface IHabitacionesRepository {

    fun getAll(): List<Habitacion>

    fun getById(id: Int): Habitacion?

    fun create(
        numCamas: Int,
        numAseos: Int
    ): Boolean

    fun update(
        id: Int,
        numCamas: Int,
        numAseos: Int,
        reservada: Boolean
    ): Boolean

    fun delete(id: Int): Boolean
}