package com.example.hostal_digital.data.mappers

import com.example.hostal_digital.data.entities.HabitacionEntity
import com.example.hostal_digital.domain.entities.Habitacion

object HabitacionMapperDataDomain {

    fun toDomain(entity: HabitacionEntity): Habitacion {
        return Habitacion(
            id = entity.id,
            numero = entity.numero,
            reservada = entity.reservada,
            numCamas = entity.numCamas,
            numAseos = entity.numAseos
        )
    }

    fun toEntity(domain: Habitacion): HabitacionEntity {
        return HabitacionEntity(
            id = domain.id,
            numero = domain.numero,
            reservada = domain.reservada,
            numCamas = domain.numCamas,
            numAseos = domain.numAseos
        )
    }
}
