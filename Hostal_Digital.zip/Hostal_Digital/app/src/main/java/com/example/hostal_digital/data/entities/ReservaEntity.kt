package com.example.hostal_digital.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity
data class ReservaEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val idHabitacion: Int,
    val idUsuario: Int,
    val fechaEntrada: Date,
    val fechaSalida: Date
)
