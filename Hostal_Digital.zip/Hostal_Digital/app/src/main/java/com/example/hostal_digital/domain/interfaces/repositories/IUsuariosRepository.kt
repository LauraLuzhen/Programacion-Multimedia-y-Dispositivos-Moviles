package com.example.hostal_digital.domain.interfaces.repositories

import com.example.hostal_digital.domain.entities.Usuario

interface IUsuariosRepository {

    fun create(
        nombre: String,
        contrasena: String
    ): Boolean

    fun getAll(): List<Usuario>

    fun getById(id: Int): Usuario?

    fun update(
        id: Int,
        nombre: String,
        contrasena: String
    ): Boolean

    fun delete(id: Int): Boolean
}
