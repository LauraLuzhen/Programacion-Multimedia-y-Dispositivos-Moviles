package com.example.hostal_digital.domain.entities

import java.util.Date

data class Reserva(
    val id: Int,
    val idHabitacion: Int,
    val idUsuario: Int,
    val fechaEntrada: Date,
    val fechaSalida: Date
)