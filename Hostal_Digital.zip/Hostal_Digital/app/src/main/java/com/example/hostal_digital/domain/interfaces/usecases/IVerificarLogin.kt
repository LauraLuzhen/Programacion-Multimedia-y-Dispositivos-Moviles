package com.example.hostal_digital.domain.interfaces.usecases

interface IVerificarLogin {

    /**
     * @return idUsuario si las credenciales son correctas, -1 si no lo son
     */
    fun verificar(
        nombre: String,
        contrasena: String
    ): Int
}
