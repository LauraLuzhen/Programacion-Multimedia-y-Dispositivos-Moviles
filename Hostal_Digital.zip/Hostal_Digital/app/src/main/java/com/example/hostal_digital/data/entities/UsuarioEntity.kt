package com.example.hostal_digital.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class UsuarioEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombre: String,
    val contrasena: String
    // Las reservas se gestionan en ReservaEntity, no aquí
)
