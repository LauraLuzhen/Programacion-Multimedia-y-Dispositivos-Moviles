package com.example.hostal_digital.data.repositories

import com.example.hostal_digital.data.dao.UsuarioDAO
import com.example.hostal_digital.data.mappers.UsuarioMapperDataDomain
import com.example.hostal_digital.domain.entities.Usuario
import com.example.hostal_digital.domain.interfaces.repositories.IUsuariosRepository

class UsuariosRepository(
    private val usuarioDao: UsuarioDAO
) : IUsuariosRepository {

    override fun create(nombre: String, contrasena: String): Boolean {
        val usuario = UsuarioMapperDataDomain.toEntity(
            Usuario(
                id = 0,
                nombre = nombre,
                contrasena = contrasena,
                reservas = emptyList()
            )
        )
        return usuarioDao.insert(usuario) > 0
    }

    override fun getAll(): List<Usuario> {
        return usuarioDao.getAll().map { UsuarioMapperDataDomain.toDomain(it) }
    }

    override fun getById(id: Int): Usuario? {
        return usuarioDao.getById(id)?.let { UsuarioMapperDataDomain.toDomain(it) }
    }

    override fun delete(id: Int): Boolean {
        val usuario = usuarioDao.getById(id) ?: return false
        return usuarioDao.delete(usuario) > 0
    }

    override fun update(id: Int, nombre: String, contrasena: String): Boolean {
        val usuario = usuarioDao.getById(id) ?: return false
        val updated = usuario.copy(nombre = nombre, contrasena = contrasena)
        return usuarioDao.update(updated) > 0
    }
}
