package com.example.hostal_digital.domain.entities

data class Usuario(
    val id: Int,
    val nombre: String,
    val contrasena: String,
    val reservas: List<Reserva> = emptyList()
)