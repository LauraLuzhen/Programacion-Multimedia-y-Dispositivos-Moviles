package com.example.hostal_digital.data.dao

import androidx.room.*
import com.example.hostal_digital.data.entities.UsuarioEntity

@Dao
interface UsuarioDAO {

    @Query("SELECT * FROM UsuarioEntity")
    fun getAll(): List<UsuarioEntity>

    @Query("SELECT * FROM UsuarioEntity WHERE id = :id")
    fun getById(id: Int): UsuarioEntity?

    @Query("SELECT * FROM UsuarioEntity WHERE nombre = :nombre")
    fun getByNombre(nombre: String): UsuarioEntity?

    @Insert
    fun insert(usuario: UsuarioEntity): Long

    @Update
    fun update(usuario: UsuarioEntity): Int

    @Delete
    fun delete(usuario: UsuarioEntity): Int
}
