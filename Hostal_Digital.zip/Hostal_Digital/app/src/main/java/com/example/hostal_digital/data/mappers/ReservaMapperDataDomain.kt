package com.example.hostal_digital.data.mappers

import com.example.hostal_digital.data.entities.ReservaEntity
import com.example.hostal_digital.domain.entities.Reserva

object ReservaMapperDataDomain {

    fun toDomain(entity: ReservaEntity): Reserva {
        return Reserva(
            id = entity.id,
            idHabitacion = entity.idHabitacion,
            idUsuario = entity.idUsuario,
            fechaEntrada = entity.fechaEntrada,
            fechaSalida = entity.fechaSalida
        )
    }

    fun toEntity(domain: Reserva): ReservaEntity {
        return ReservaEntity(
            id = domain.id,
            idHabitacion = domain.idHabitacion,
            idUsuario = domain.idUsuario,
            fechaEntrada = domain.fechaEntrada,
            fechaSalida = domain.fechaSalida
        )
    }
}
