package com.example.hostal_digital.domain.entities

data class Habitacion(
    val id: Int,
    val numero: Int,
    val reservada: Boolean,
    val numCamas: Int,
    val numAseos: Int
)
