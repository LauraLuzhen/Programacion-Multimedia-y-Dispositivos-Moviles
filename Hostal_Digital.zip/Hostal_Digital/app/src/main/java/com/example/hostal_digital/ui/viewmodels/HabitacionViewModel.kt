package com.example.hostal_digital.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.hostal_digital.domain.entities.Habitacion
import com.example.hostal_digital.domain.usecases.HabitacionUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Date

class HabitacionViewModel(
    private val habitacionUseCase: HabitacionUseCase
) : ViewModel() {

    private val _habitacionSeleccionada = MutableStateFlow<Habitacion?>(null)
    val habitacionSeleccionada: StateFlow<Habitacion?> get() = _habitacionSeleccionada

    private val _reservaSuccess = MutableStateFlow<Boolean?>(null)
    val reservaSuccess: StateFlow<Boolean?> get() = _reservaSuccess

    // Mostrar características de la habitación seleccionada
    fun verHabitacion(idHabitacion: Int) {
        viewModelScope.launch {
            _habitacionSeleccionada.value = habitacionUseCase.caracteristicas(idHabitacion)
        }
    }

    /**
     * Reservar habitación
     * @param idHabitacion: ID de la habitación seleccionada
     * @param idUsuario: ID del usuario logueado
     * @param fechaEntrada: Fecha de entrada
     * @param fechaSalida: Fecha de salida
     */
    fun reservarHabitacion(
        idHabitacion: Int,
        idUsuario: Int,
        fechaEntrada: Date,
        fechaSalida: Date
    ) {
        viewModelScope.launch {
            val success = habitacionUseCase.reservar(
                idHabitacion,
                idUsuario,
                fechaEntrada,
                fechaSalida
            )
            _reservaSuccess.value = success
        }
    }

    companion object {
        fun provideFactory(habitacionUseCase: HabitacionUseCase) = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return HabitacionViewModel(habitacionUseCase) as T
            }
        }
    }
}
