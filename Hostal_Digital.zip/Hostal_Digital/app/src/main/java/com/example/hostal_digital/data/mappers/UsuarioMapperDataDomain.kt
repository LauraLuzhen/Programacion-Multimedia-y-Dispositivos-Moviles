package com.example.hostal_digital.data.mappers

import com.example.hostal_digital.data.entities.UsuarioEntity
import com.example.hostal_digital.domain.entities.Usuario
import com.example.hostal_digital.domain.entities.Reserva

object UsuarioMapperDataDomain {

    fun toDomain(entity: UsuarioEntity, reservas: List<Reserva> = emptyList()): Usuario {
        return Usuario(
            id = entity.id,
            nombre = entity.nombre,
            contrasena = entity.contrasena,
            reservas = reservas
        )
    }

    fun toEntity(domain: Usuario): UsuarioEntity {
        return UsuarioEntity(
            id = domain.id,
            nombre = domain.nombre,
            contrasena = domain.contrasena
        )
    }
}
