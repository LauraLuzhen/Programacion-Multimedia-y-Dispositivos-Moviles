package com.example.hostal_digital.data.dao

import androidx.room.*
import com.example.hostal_digital.data.entities.HabitacionEntity

@Dao
interface HabitacionDAO {

    @Query("SELECT * FROM HabitacionEntity")
    fun getAll(): List<HabitacionEntity>

    @Query("SELECT * FROM HabitacionEntity WHERE id = :id")
    fun getById(id: Int): HabitacionEntity?

    @Insert
    fun insert(habitacion: HabitacionEntity): Long

    @Update
    fun update(habitacion: HabitacionEntity): Int

    @Delete
    fun delete(habitacion: HabitacionEntity): Int
}
