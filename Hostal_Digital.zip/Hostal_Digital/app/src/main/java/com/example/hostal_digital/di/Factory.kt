package com.example.hostal_digital.di

import android.content.Context
import com.example.hostal_digital.data.database.AppDatabase
import com.example.hostal_digital.data.repositories.HabitacionesRepository
import com.example.hostal_digital.data.repositories.ReservasRepository
import com.example.hostal_digital.data.repositories.UsuariosRepository
import com.example.hostal_digital.domain.usecases.HabitacionUseCase
import com.example.hostal_digital.domain.usecases.ListarHabitacionesUseCase
import com.example.hostal_digital.domain.usecases.LoginRegistroUseCase

object Factory {

    // Room Database
    private var database: AppDatabase? = null

    fun provideDatabase(context: Context): AppDatabase {
        return database ?: AppDatabase.getDatabase(context).also { database = it }
    }

    // DAOs
    fun provideHabitacionDao(context: Context) = provideDatabase(context).habitacionDao()
    fun provideUsuarioDao(context: Context) = provideDatabase(context).usuarioDao()
    fun provideReservaDao(context: Context) = provideDatabase(context).reservaDao()

    // Repositories
    fun provideHabitacionesRepository(context: Context) =
        HabitacionesRepository(provideHabitacionDao(context))

    fun provideUsuariosRepository(context: Context) =
        UsuariosRepository(provideUsuarioDao(context))

    fun provideReservasRepository(context: Context) =
        ReservasRepository(provideReservaDao(context))

    // UseCases
    fun provideHabitacionUseCase(context: Context): HabitacionUseCase {
        return HabitacionUseCase(
            habitacionesRepository = provideHabitacionesRepository(context),
            reservasRepository = provideReservasRepository(context)
        )
    }

    fun provideListarHabitacionesUseCase(context: Context): ListarHabitacionesUseCase {
        return ListarHabitacionesUseCase(
            habitacionesRepository = provideHabitacionesRepository(context),
            usuariosRepository = provideUsuariosRepository(context),
            reservasRepository = provideReservasRepository(context)
        )
    }

    fun provideLoginRegistroUseCase(context: Context): LoginRegistroUseCase {
        return LoginRegistroUseCase(
            usuariosRepository = provideUsuariosRepository(context)
        )
    }
}
