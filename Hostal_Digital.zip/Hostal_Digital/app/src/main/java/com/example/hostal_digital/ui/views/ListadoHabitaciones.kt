package com.example.hostal_digital.ui.views

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.hostal_digital.domain.entities.Habitacion

@Composable
fun ListadoHabitaciones(
    habitaciones: List<Habitacion>,
    usuarioId: Int?,
    onHabitacionClick: (Habitacion) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxSize().padding(16.dp)) {
        if (habitaciones.isEmpty()) {
            Text("NO VACANCY", style = MaterialTheme.typography.titleMedium)
        } else {
            LazyColumn {
                items(habitaciones) { habitacion ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { onHabitacionClick(habitacion) }
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text("Habitación ${habitacion.numero}", style = MaterialTheme.typography.titleMedium)
                            Text("Camas: ${habitacion.numCamas}, Aseos: ${habitacion.numAseos}")
                            Text("Reservada: ${if (habitacion.reservada) "Sí" else "No"}")
                        }
                    }
                }
            }
        }
    }
}
