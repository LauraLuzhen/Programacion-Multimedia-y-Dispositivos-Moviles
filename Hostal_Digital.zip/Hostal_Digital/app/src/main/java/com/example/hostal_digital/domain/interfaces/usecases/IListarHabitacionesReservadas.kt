package com.example.hostal_digital.domain.interfaces.usecases

import com.example.hostal_digital.domain.entities.Reserva

interface IListarHabitacionesReservadas {

    fun getAll(idUsuario: Int): List<Reserva>
}
