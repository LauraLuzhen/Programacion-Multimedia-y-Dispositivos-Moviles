package com.example.hostal_digital.ui.views

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.hostal_digital.ui.viewmodels.HabitacionViewModel

@Composable
fun HabitacionCaract(
    viewModel: HabitacionViewModel,
    idHabitacion: Int,
    modifier: Modifier = Modifier
) {
    val habitacion by viewModel.habitacionSeleccionada.collectAsStateWithLifecycle()
    LaunchedEffect(idHabitacion) { viewModel.verHabitacion(idHabitacion) }

    Column(modifier = modifier.fillMaxSize().padding(16.dp)) {
        habitacion?.let {
            Text("Habitación ${it.numero}", style = MaterialTheme.typography.titleLarge)
            Text("Camas: ${it.numCamas}, Aseos: ${it.numAseos}")
            Text("Reservada: ${if (it.reservada) "Sí" else "No"}")
        } ?: Text("Cargando...")
    }
}
