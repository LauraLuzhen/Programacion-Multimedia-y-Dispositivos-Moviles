package com.example.hostal_digital.domain.usecases

import com.example.hostal_digital.domain.entities.Habitacion
import com.example.hostal_digital.domain.interfaces.repositories.IHabitacionesRepository
import com.example.hostal_digital.domain.interfaces.repositories.IReservasRepository
import com.example.hostal_digital.domain.interfaces.usecases.IHabitacionCaract
import com.example.hostal_digital.domain.interfaces.usecases.IReservarHabitacion
import java.util.Date

class HabitacionUseCase(
    private val habitacionesRepository: IHabitacionesRepository,
    private val reservasRepository: IReservasRepository
) : IHabitacionCaract, IReservarHabitacion {

    /**
     * Devuelve las características de una habitación concreta
     */
    override fun caracteristicas(idHabitacion: Int): Habitacion? {
        return habitacionesRepository.getById(idHabitacion)
    }

    /**
     * Realiza la reserva de una habitación para un usuario logueado
     */
    override fun reservar(
        idHabitacion: Int,
        idUsuario: Int,
        fechaEntrada: Date,
        fechaSalida: Date
    ): Boolean {

        // El admin NO puede reservar habitaciones
        if (idUsuario == 0) return false

        val habitacion = habitacionesRepository.getById(idHabitacion)
            ?: return false

        // No se puede reservar si ya está reservada
        if (habitacion.reservada) return false

        // Crear la reserva
        val reservaCreada = reservasRepository.create(
            idHabitacion = idHabitacion,
            idUsuario = idUsuario,
            fechaEntrada = fechaEntrada,
            fechaSalida = fechaSalida
        )

        if (!reservaCreada) return false

        // Marcar la habitación como reservada
        return habitacionesRepository.update(
            id = habitacion.id,
            numCamas = habitacion.numCamas,
            numAseos = habitacion.numAseos,
            reservada = true
        )
    }
}
