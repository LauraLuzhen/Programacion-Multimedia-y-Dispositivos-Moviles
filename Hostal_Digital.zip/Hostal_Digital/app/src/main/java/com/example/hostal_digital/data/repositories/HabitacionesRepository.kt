package com.example.hostal_digital.data.repositories

import com.example.hostal_digital.data.dao.HabitacionDAO
import com.example.hostal_digital.data.mappers.HabitacionMapperDataDomain
import com.example.hostal_digital.domain.entities.Habitacion
import com.example.hostal_digital.domain.interfaces.repositories.IHabitacionesRepository

class HabitacionesRepository(
    private val habitacionDao: HabitacionDAO
) : IHabitacionesRepository {

    override fun getAll(): List<Habitacion> {
        return habitacionDao.getAll().map { HabitacionMapperDataDomain.toDomain(it) }
    }

    override fun getById(id: Int): Habitacion? {
        return habitacionDao.getById(id)?.let { HabitacionMapperDataDomain.toDomain(it) }
    }

    override fun create(numCamas: Int, numAseos: Int): Boolean {
        val habitacion = HabitacionMapperDataDomain.toEntity(
            Habitacion(
                numero = (getAll().maxOfOrNull { it.numero } ?: 0) + 1,
                reservada = false,
                numCamas = numCamas,
                numAseos = numAseos,
                id = 0
            )
        )
        return habitacionDao.insert(habitacion) > 0
    }

    override fun delete(id: Int): Boolean {
        val habitacion = habitacionDao.getById(id) ?: return false
        return habitacionDao.delete(habitacion) > 0
    }

    override fun update(id: Int, numCamas: Int, numAseos: Int, reservada: Boolean): Boolean {
        val habitacion = habitacionDao.getById(id) ?: return false
        val updated = habitacion.copy(
            numCamas = numCamas,
            numAseos = numAseos,
            reservada = reservada
        )
        return habitacionDao.update(updated) > 0
    }
}
