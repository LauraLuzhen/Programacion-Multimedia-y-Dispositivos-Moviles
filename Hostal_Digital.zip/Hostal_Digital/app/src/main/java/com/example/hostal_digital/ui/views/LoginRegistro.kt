package com.example.hostal_digital.ui.views

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.hostal_digital.ui.viewmodels.LoginRegistroViewModel

@Composable
fun LoginRegistro(
    viewModel: LoginRegistroViewModel,
    onLoginSuccess: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var nombre by remember { mutableStateOf("") }
    var contrasena by remember { mutableStateOf("") }
    val error by viewModel.loginError.collectAsStateWithLifecycle()

    Column(modifier = modifier.fillMaxSize().padding(16.dp)) {
        Text("Login / Registro", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = nombre,
            onValueChange = { nombre = it },
            label = { Text("Nombre") }
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = contrasena,
            onValueChange = { contrasena = it },
            label = { Text("Contraseña") }
        )
        Spacer(modifier = Modifier.height(16.dp))
        if (error != null) Text(error ?: "", color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(8.dp))
        Row {
            Button(onClick = { viewModel.login(nombre, contrasena, onLoginSuccess) }) {
                Text("Login")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(onClick = { viewModel.registrar(nombre, contrasena) { onLoginSuccess(-1) } }) {
                Text("Registrar")
            }
        }
    }
}
