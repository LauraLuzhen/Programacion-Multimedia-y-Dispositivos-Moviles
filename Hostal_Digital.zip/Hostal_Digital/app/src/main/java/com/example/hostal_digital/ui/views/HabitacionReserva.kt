package com.example.hostal_digital.ui.views

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.hostal_digital.ui.viewmodels.HabitacionViewModel
import java.util.*

@Composable
fun HabitacionReserva(
    viewModel: HabitacionViewModel,
    idHabitacion: Int,
    usuarioId: Int,
    modifier: Modifier = Modifier
) {
    val reservaSuccess by viewModel.reservaSuccess.collectAsStateWithLifecycle()
    var fechaEntrada by remember { mutableStateOf(Date()) }
    var fechaSalida by remember { mutableStateOf(Date()) }

    Column(modifier = modifier.fillMaxSize().padding(16.dp)) {
        Text("Reservar habitación $idHabitacion", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))

        // Por simplicidad, aquí simulamos que el usuario ya define las fechas
        OutlinedTextField(
            value = fechaEntrada.toString(),
            onValueChange = { /* Podrías parsear fecha */ },
            label = { Text("Fecha Entrada (solo texto)") }
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = fechaSalida.toString(),
            onValueChange = { /* Podrías parsear fecha */ },
            label = { Text("Fecha Salida (solo texto)") }
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { viewModel.reservarHabitacion(idHabitacion, usuarioId, fechaEntrada, fechaSalida) }) {
            Text("Reservar")
        }

        reservaSuccess?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (it) "Reserva realizada con éxito" else "No se pudo reservar",
                color = if (it) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
        }
    }
}
